#include<iostream>
#define MaxSize 100
using namespace std;

typedef struct
{
	int *elem;
	int length;
}SqList;

int InitList(SqList &L)
{
	L.elem=new int[MaxSize];
	if(!L.elem) exit(0);
	L.length=0;
	return 1;
}

int newElem(SqList &L,int i)
{
	for(int j=0;j<i;j++)
	{
		L.elem[j]=j+1;
		++L.length;
	}
	return 1;
}

int ListDelete(SqList &L,int i)
{
	if(i<1||i>L.length) return 0;
	for(int j=i;j<=L.length-1;j++)
		L.elem[j-1]=L.elem[j];
	--L.length;
	return 1;
}

void main()
{
	int m,n,i,k;
	SqList L;
	cout<<"�������ݣ�����m,n m,n Ϊ������n<m:"<<endl;
	cin>>m>>n;
	InitList(L);
	newElem(L,m);
	k=n;
	i=0;
	while(L.length-1)
	{
		if(n>L.length)
		{
			k=k%L.length;
			ListDelete(L,k);
			i++;
		}
		else
		{
			ListDelete(L,n);
			i++;
		}
	}
	cout<<"������"<<L.elem[0]<<"��"<<endl;
	cout<<"������"<<i<<endl;
}
#include<iostream>
#define MAXSIZE 100
using namespace std;

typedef struct
{
	int xuhao;
	int yuwen;
	int shuxue;
	int yingyu;
	int count;
}Grade;

typedef struct
{
	Grade *elem;
	int length;
}List;

void InitList(List &L)
{
	L.elem=new Grade[MAXSIZE];
	if(!L.elem) exit(0);
	L.length=0;
}

void newElem(List &L,int n)
{
	for(int i=0;i<n;i++)
	{
		L.elem[i].xuhao=i+1;
		cin>>L.elem[i].yuwen>>L.elem[i].shuxue>>L.elem[i].yingyu;
		L.elem[i].count=L.elem[i].yuwen+L.elem[i].shuxue+L.elem[i].yingyu;
		++L.length;
	}
}

void coutElem5(List L)
{
	for(int i=0;i<5;i++)
	{
		cout<<L.elem[i].xuhao<<" "<<L.elem[i].count<<endl;
	}
}

void MaxElem(List &L,int n)
{
	int j;
	Grade r;
	for(int i=0;i<n-1;i++)
	{
		for(j=i+1;j<n;j++)
	{
		if(L.elem[i].count<L.elem[j].count)
		{
			r=L.elem[i];
			L.elem[i]=L.elem[j];
			L.elem[j]=r;
		}
		else if(L.elem[i].count==L.elem[j].count)
		{
			if(L.elem[i].yuwen<L.elem[j].yuwen)
			{
				r=L.elem[i];
				L.elem[i]=L.elem[j];
				L.elem[j]=r;
			}
			else if(L.elem[i].yuwen==L.elem[j].yuwen)
			{
				if(L.elem[i].xuhao>L.elem[j].xuhao)
				{
					r=L.elem[i];
					L.elem[i]=L.elem[j];
					L.elem[j]=r;
				}
			}
		}
	}
	}
}

void main()
{
	List L;
	int n;
	cout<<"�����У�μ���ѡ��ѧ�������͸��Ƴɼ�:"<<endl;
	InitList(L);
	cin>>n;
	newElem(L,n);
	cout<<"֮ǰ"<<endl;
	MaxElem(L,n);
	cout<<"�����"<<endl;
	coutElem5(L);
}
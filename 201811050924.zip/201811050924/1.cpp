#include<iostream>
using namespace std;

int funa(int a,int b)
{int c;
c=a/10*10+a%10*1000+b/10+b%10*100;
return c;
}

void funb(int a,int b,int &c)
{
c=a/10*10+a%10*1000+b/10+b%10*100;
}

void func(int a,int b,int *p)
{
*p=a/10*10+a%10*1000+b/10+b%10*100;
}

void main()
{int a,b,c;
cout<<"������a,b,c�Ĵ�С\n";
cin>>a>>b;
c=funa(a,b);
cout<<"(1)"<<c<<endl;
c=0;   //c��ʼ��
funb(a,b,c);
cout<<"(2)"<<c<<endl;
c=0;   //c��ʼ��
int *p;
p=&c;
func(a,b,p);
cout<<"(3)"<<c<<endl;
}
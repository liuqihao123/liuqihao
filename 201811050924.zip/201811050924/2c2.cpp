#include<iostream>
#include<stdio.h>
#define MaxSize 100
#define NULL 0
#define OK 1
#define ERROR 0
using namespace std;

typedef struct LNode
{
	int data;
	struct LNode *next;
}LNode,*LinkList;

int InitList(LinkList &L)
{
	L=new LNode;
	L->next=NULL;
	return OK;
}

void CreateList(LinkList &L,int n)
{
	L=new LNode;
	L->next=NULL;
	LinkList r=L;
	LinkList p;
	for(int i=0;i<n;++i)
	{
		p=new LNode;
		p->data=i+1;
		p->next=NULL;r->next=p;
		r=p;
	}
}

int ListDelete(LinkList &L,int i)
{
	LinkList p,q;
	int j;
	p=L;j=0;
	while((p->next)&&(j<i-1))
	{p=p->next;++j;}
	if(!(p->next)||(j>i-1)) return ERROR;
	q=p->next;
	p->next=q->next;
	delete q;
	return OK;
}

void main()
{
	int m,n,i,length,k;
	LinkList L;
	cout<<"�������ݣ�����m,n m,n Ϊ������n<m:"<<endl;
	cin>>m>>n;
	CreateList(L,m);
	length=m;
	k=n;
	i=0;
	while(L->next->next!=NULL)
	{
		if(n>length)
		{
			k=k%length;
			ListDelete(L,k);
			i++;
		}
		else
		{
			ListDelete(L,n);
			i++;
		}
		length--;
	}
	cout<<"������"<<L->next->data<<"��"<<endl;
	cout<<"������"<<i<<endl;
}